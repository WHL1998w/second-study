<template>
  <div class="box1">

    <div class="head">
      <img
        style="width: 100%; height: 400px; margin:auto; border-radius: 8px;"
        src="../assets/image/bg1.jpg"
        alt=""
      >
    </div>

    <div class="content">
      <div style="margin-bottom: 10px;">
        <span class="title">管理员登陆</span>
      </div>
      <div class="content-head">
        <p
          class="font"
          style="margin-bottom: 20px;"
        >请使用账号密码或人脸登录</p>
        <img
          src="../assets/image/menu.png"
          style="width: 50px; height: 50px; margin-bottom: 10px;"
          alt=""
        >
      </div>
      <div style="display: flex; flex-direction: column; width: 100%;">
        <input
          type="text"
          placeholder="USERNAME"
          class="input1"
        >
        <input
          type="pasword"
          placeholder="PASSWORD"
          class="input1"
        >
      </div>
      <div class="bottom">
        <div style="display: flex; align-items: center;">
          <input type="checkbox" />
          <span class="font">人脸识别登录</span>
        </div>
        <div>
          <span class="font1">建议在Chorem下使用本系统</span>
        </div>
      </div>

      <Button class="login-btn">戳我登录</Button>
    </div>
  </div>
</template>

<script>
export default {
  name: "index",
};
</script>

<style scoped>
</style>